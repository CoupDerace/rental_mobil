import 'package:get_it/get_it.dart';

import '../../features/auth/data/datasource/auth_remote_datasource.dart';
import '../../features/auth/data/repositories/auth_repository_impl.dart';
import '../../features/auth/domain/repositories/auth_repository.dart';
import '../../features/auth/domain/usecases/login_usecase.dart';
import '../../features/auth/domain/usecases/logout_usecase.dart';
import '../../features/auth/presentation/providers/login_provider.dart';

import '../../features/dashboard/data/datasource/dashboard_remote_datasource.dart';
import '../../features/dashboard/data/repositories/dashboard_repository_impl.dart';
import '../../features/dashboard/domain/repositories/dashboard_repository.dart';
import '../../features/dashboard/domain/usecases/get_active_services.dart';
import '../../features/dashboard/domain/usecases/get_dashboard_usecase.dart';
import '../../features/dashboard/domain/usecases/get_recent_activities.dart';
import '../../features/dashboard/domain/usecases/get_statistics.dart';
import '../../features/dashboard/presentation/providers/dashboard_provider.dart';

final sl = GetIt.instance;

Future<void> initInjector() async {
  // ================= AUTH =================
  sl.registerLazySingleton<AuthRemoteDataSource>(
    () => AuthRemoteDataSourceImpl(),
  );

  sl.registerLazySingleton<AuthRepository>(
    () => AuthRepositoryImpl(sl()),
  );

  sl.registerLazySingleton(
    () => LoginUseCase(sl()),
  );

  sl.registerLazySingleton(
    () => LogoutUseCase(sl()),
  );

  sl.registerFactory(
    () => LoginProvider(
      loginUseCase: sl(),
    ),
  );

  // ================= DASHBOARD =================
  sl.registerLazySingleton<DashboardRemoteDatasource>(
    () => DashboardRemoteDatasourceImpl(),
  );

  sl.registerLazySingleton<DashboardRepository>(
    () => DashboardRepositoryImpl(sl()),
  );

  sl.registerLazySingleton(
    () => GetDashboardUseCase(sl()),
  );

  sl.registerLazySingleton(
    () => GetRecentActivities(sl()),
  );

  sl.registerLazySingleton(
    () => GetStatistics(sl()),
  );

  sl.registerLazySingleton(
    () => GetActiveServices(sl()),
  );

  sl.registerFactory(
    () => DashboardProvider(
      getDashboardUseCase: sl(),
      getRecentActivities: sl(),
      getStatistics: sl(),
      getActiveServices: sl(),
    ),
  );
}
