import 'package:flutter/material.dart';

import '../../../../app/routes/routes.dart';
import '../../../../shared/providers/auth_provider.dart';
import 'package:provider/provider.dart';

class SplashProvider extends ChangeNotifier {
  Future<void> initialize(BuildContext context) async {
    final auth = context.read<AuthProvider>();

    await auth.loadSession();

    if (!context.mounted) return;

    if (!auth.isAuthenticated) {
      Navigator.pushReplacementNamed(
        context,
        AppRoutes.login,
      );
      return;
    }

    switch (auth.role) {
      case "admin":
        Navigator.pushReplacementNamed(
          context,
          AppRoutes.adminDashboard,
        );
        break;

      case "owner":
        Navigator.pushReplacementNamed(
          context,
          AppRoutes.ownerDashboard,
        );
        break;

      case "operator":
        Navigator.pushReplacementNamed(
          context,
          AppRoutes.operatorDashboard,
        );
        break;

      default:
        Navigator.pushReplacementNamed(
          context,
          AppRoutes.login,
        );
    }
  }
}