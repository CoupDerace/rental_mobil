import 'package:rental_mobil/core/network/supabase_service.dart';

import '../models/active_service_model.dart';
import '../models/dashboard_model.dart';
import '../models/recent_activity.dart';
import '../models/statistic_model.dart';

abstract class DashboardRemoteDatasource {
  Future<DashboardModel> getDashboard();
  Future<List<RecentActivityModel>> getRecentActivities();
  Future<List<StatisticModel>> getStatistics();
  Future<List<ActiveServiceModel>> getActiveServices();
}

class DashboardRemoteDatasourceImpl implements DashboardRemoteDatasource {
  @override
  Future<DashboardModel> getDashboard() async {
    final result = await SupabaseService.client.rpc('get_dashboard');
    return DashboardModel.fromJson(result);
  }

  @override
  Future<List<RecentActivityModel>> getRecentActivities() async {
    final result = await SupabaseService.from('laporan_transaksi_rental')
        .select()
        .order('created_at', ascending: false)
        .limit(5);
    return (result as List)
        .map((e) => RecentActivityModel.fromJson(e))
        .toList();
  }

  @override
  Future<List<StatisticModel>> getStatistics() async {
    final dashboard = await getDashboard();
    return [
      StatisticModel(
        title: 'Mobil',
        value: dashboard.totalMobil,
      ),
      StatisticModel(
        title: 'Rental',
        value: dashboard.totalRental,
      ),
      StatisticModel(
        title: 'Pelanggan',
        value: dashboard.totalPelanggan,
      ),
      StatisticModel(
        title: 'Disewa',
        value: dashboard.mobilDisewa,
      ),
    ];
  }

  @override
  Future<List<ActiveServiceModel>> getActiveServices() async {
    final result = await SupabaseService.from('service_mobil')
        .select()
        .eq('status', 'sedang_berjalan');
    return (result as List)
        .map((e) => ActiveServiceModel.fromJson(e))
        .toList();
  }
}
