import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rental_mobil/app/routes/injector.dart';
import 'package:rental_mobil/shared/providers/auth_provider.dart';

import '../providers/dashboard_provider.dart';
import 'admin_dashboard.dart';
import 'operator_dashboard.dart';
import 'owner_dashboard.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final role = auth.role;

    return ChangeNotifierProvider(
      create: (_) => sl<DashboardProvider>(),
      child: Builder(
        builder: (context) {
          switch (role) {
            case 'admin':
              return const _AutoLoadDashboard(child: AdminDashboard());
            case 'owner':
              return const _AutoLoadDashboard(child: OwnerDashboard());
            case 'operator':
              return const OperatorDashboard();
            default:
              return const Scaffold(
                body: Center(child: Text('Role tidak dikenal')),
              );
          }
        },
      ),
    );
  }
}

class _AutoLoadDashboard extends StatefulWidget {
  final Widget child;
  const _AutoLoadDashboard({required this.child});

  @override
  State<_AutoLoadDashboard> createState() => _AutoLoadDashboardState();
}

class _AutoLoadDashboardState extends State<_AutoLoadDashboard> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<DashboardProvider>().loadDashboard();
    });
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}
