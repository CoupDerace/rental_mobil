import 'package:flutter/material.dart';

class DashboardScaffold extends StatelessWidget {
  final Widget body;
  final String title;
  final int selectedIndex;
  final ValueChanged<int>? onMenuTap;

  const DashboardScaffold({
    super.key,
    required this.body,
    required this.title,
    this.selectedIndex = 0,
    this.onMenuTap,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: body,
    );
  }
}
