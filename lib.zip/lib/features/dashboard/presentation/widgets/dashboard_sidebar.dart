import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:rental_mobil/shared/providers/auth_provider.dart';

class DashboardSidebar extends StatelessWidget {
  const DashboardSidebar({super.key});

  static List<_SidebarItem> getAdminMenu() => const [
        _SidebarItem(title: 'Dashboard', icon: Icons.dashboard, route: 'dashboard'),
        _SidebarItem(title: 'Mobil', icon: Icons.directions_car, route: 'mobil'),
        _SidebarItem(title: 'Driver', icon: Icons.badge, route: 'driver'),
        _SidebarItem(title: 'Pelanggan', icon: Icons.people, route: 'pelanggan'),
        _SidebarItem(title: 'Rental', icon: Icons.receipt_long, route: 'rental'),
        _SidebarItem(title: 'Pembayaran', icon: Icons.payments, route: 'pembayaran'),
        _SidebarItem(title: 'Service', icon: Icons.build, route: 'service'),
        _SidebarItem(title: 'Laporan', icon: Icons.bar_chart, route: 'laporan'),
        _SidebarItem(title: 'User', icon: Icons.admin_panel_settings, route: 'user'),
      ];

  static List<_SidebarItem> getOwnerMenu() => const [
        _SidebarItem(title: 'Dashboard', icon: Icons.dashboard, route: 'dashboard'),
        _SidebarItem(title: 'Laporan', icon: Icons.bar_chart, route: 'laporan'),
      ];

  static List<_SidebarItem> getOperatorMenu() => const [
        _SidebarItem(title: 'Dashboard Service', icon: Icons.dashboard, route: 'dashboard'),
        _SidebarItem(title: 'Service', icon: Icons.build, route: 'service'),
      ];

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final role = auth.role;

    final menu = switch (role) {
      'admin' => getAdminMenu(),
      'owner' => getOwnerMenu(),
      _ => getOperatorMenu(),
    };

    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            _buildHeader(context, auth),
            const Divider(height: 1),
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: menu
                    .map((item) => _buildMenuItem(context, item))
                    .toList(),
              ),
            ),
            const Divider(height: 1),
            _buildLogoutTile(context),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context, AuthProvider auth) {
    final nama = auth.profile?['nama'] ?? '-';
    final role = auth.role;
    final roleDisplay = role.isNotEmpty ? role[0].toUpperCase() + role.substring(1) : '-';

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 12),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: Theme.of(context).colorScheme.primary,
            radius: 24,
            child: Text(
              nama.isNotEmpty ? nama[0].toUpperCase() : '-',
              style: const TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  nama,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  roleDisplay,
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItem(BuildContext context, _SidebarItem item) {
    return ListTile(
      leading: Icon(item.icon),
      title: Text(item.title),
      onTap: () {
        Navigator.pop(context);
      },
    );
  }

  Widget _buildLogoutTile(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.logout, color: Colors.red),
      title: const Text(
        'Logout',
        style: TextStyle(color: Colors.red),
      ),
      onTap: () => _showLogoutDialog(context),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Logout'),
        content: const Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              final auth = context.read<AuthProvider>();
              await auth.logout();
              if (context.mounted) {
                Navigator.of(context).pushNamedAndRemoveUntil(
                  '/login',
                  (route) => false,
                );
              }
            },
            child: const Text('Logout', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }
}

class _SidebarItem {
  final String title;
  final IconData icon;
  final String route;

  const _SidebarItem({
    required this.title,
    required this.icon,
    required this.route,
  });
}
