import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'dashboard_card.dart';
import '../providers/dashboard_provider.dart';

class DashboardGrid extends StatelessWidget {
  const DashboardGrid({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DashboardProvider>();
    final d = provider.dashboard;

    return LayoutBuilder(
      builder: (context, constraints) {
        final count = constraints.maxWidth >= 1024 ? 3 : 2;
        return GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          crossAxisCount: count,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
          childAspectRatio: count >= 3 ? 1.4 : 1.3,
          children: [
            DashboardCard(
              icon: Icons.directions_car,
              title: 'Total Mobil',
              value: '${d?.totalMobil ?? 0}',
              color: Colors.blue,
            ),
            DashboardCard(
              icon: Icons.check_circle_outline,
              title: 'Mobil Tersedia',
              value: '${d?.mobilTersedia ?? 0}',
              color: Colors.green,
            ),
            DashboardCard(
              icon: Icons.car_rental,
              title: 'Mobil Disewa',
              value: '${d?.mobilDisewa ?? 0}',
              color: Colors.orange,
            ),
            DashboardCard(
              icon: Icons.people_outline,
              title: 'Total Pelanggan',
              value: '${d?.totalPelanggan ?? 0}',
              color: Colors.purple,
            ),
            DashboardCard(
              icon: Icons.receipt_long,
              title: 'Total Rental',
              value: '${d?.totalRental ?? 0}',
              color: Colors.red,
            ),
            DashboardCard(
              icon: Icons.attach_money,
              title: 'Total Pendapatan',
              value: 'Rp ${(d?.totalPendapatan ?? 0).toStringAsFixed(0)}',
              color: Colors.teal,
            ),
          ],
        );
      },
    );
  }
}
